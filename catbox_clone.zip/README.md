# Catbox Clone

A lightweight file & paste hosting service inspired by catbox.moe.

## Setup

### Backend
```bash
cd backend
npm install
cp .env.example .env
npm start
```

### Frontend
Serve via GitHub Pages or any static host.

## License
MIT
